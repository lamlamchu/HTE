import { useState, useEffect } from "react";

interface TaskbarProps {
  openWindows: { id: string; title: string; minimized: boolean }[];
  onWindowClick: (id: string) => void;
}

export default function Taskbar({ openWindows, onWindowClick }: TaskbarProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const timeStr = time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="h-10 bg-taskbar pixel-border-outset flex items-center px-1 gap-1 z-50">
      {/* Start button */}
      <button className="h-7 px-3 pixel-border-outset bg-secondary flex items-center gap-1 active:pixel-border-inset font-pixel text-[8px] text-foreground">
        <span className="text-sm">🖥️</span>
        Start
      </button>

      <div className="w-px h-6 bg-border mx-1" />

      {/* Open windows */}
      <div className="flex-1 flex gap-1 overflow-x-auto">
        {openWindows.map((win) => (
          <button
            key={win.id}
            onClick={() => onWindowClick(win.id)}
            className={`
              h-7 px-3 min-w-[120px] max-w-[200px] truncate
              font-vt323 text-sm text-foreground
              ${win.minimized ? 'pixel-border-outset bg-secondary' : 'pixel-border-inset bg-muted'}
            `}
          >
            {win.title}
          </button>
        ))}
      </div>

      {/* Clock */}
      <div className="h-7 px-3 pixel-border-inset bg-secondary flex items-center font-vt323 text-sm text-foreground">
        {timeStr}
      </div>
    </div>
  );
}
