import { useState, useEffect, useRef, useCallback } from "react";
import { Mail, Trash2, Reply, ShieldAlert, AlertTriangle, Inbox, Star, Download } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface Email {
  id: number;
  from: string;
  subject: string;
  preview: string;
  body: string;
  time: string;
  read: boolean;
  starred: boolean;
  isPhishing: boolean;
  isMalware?: boolean;
  malwareFileName?: string;
  phishingReason?: string;
  phishingTip?: string;
  suspiciousLink?: string;
}

interface PixelMailAppProps {
  onMalwareDownload?: (fileName: string, reason: string, tip: string) => void;
}

const SAFE_EMAILS: Omit<Email, "id" | "time" | "read" | "starred">[] = [
  { from: "mom@family.com", subject: "Dinner tonight 🍕", preview: "Hey sweetie! What do you want for dinner tonight?", body: "Hey sweetie!\n\nWhat do you want for dinner tonight? Dad suggested pizza but I was thinking maybe we could try that new pasta recipe.\n\nLove you! ❤️\n- Mom", isPhishing: false },
  { from: "teacher@school.edu", subject: "Homework reminder", preview: "Don't forget to submit your science project by Friday!", body: "Hi class,\n\nJust a reminder that your science projects are due this Friday. Make sure to include your hypothesis and conclusion.\n\nSubmit here: https://school.edu/submit\n\nGood luck!\n- Mrs. Johnson", isPhishing: false, suspiciousLink: "https://school.edu/submit" },
  { from: "friend_alex@email.com", subject: "Movie this weekend?", preview: "Hey! Want to watch the new superhero movie Saturday?", body: "Hey!\n\nThe new superhero movie comes out this Saturday. Want to go with me and Sam? My mom said she can drive us!\n\nCheck showtimes: https://movies.com/showtimes\n\nLet me know! 🎬\n- Alex", isPhishing: false, suspiciousLink: "https://movies.com/showtimes" },
  { from: "library@school.edu", subject: "Book available for pickup", preview: "The book you requested is ready at the school library.", body: "Hello,\n\nThe book 'Adventures in Space' that you requested is now available for pickup at the school library.\n\nLibrary catalog: https://school.edu/library\n\nHappy reading! 📚\n- School Library", isPhishing: false, suspiciousLink: "https://school.edu/library" },
  { from: "coach@sportsclub.org", subject: "Practice schedule update", preview: "Practice moved to 4pm this Thursday.", body: "Hi team!\n\nJust a heads up - Thursday's practice has been moved to 4:00 PM instead of 3:30 PM. The gym will be available for warm-ups at 3:45.\n\nSchedule: https://sportsclub.org/schedule\n\nSee you there! 🏀\n- Coach Davis", isPhishing: false, suspiciousLink: "https://sportsclub.org/schedule" },
  { from: "grandma@family.com", subject: "Happy Birthday coming up! 🎂", preview: "Can't wait for your birthday next week!", body: "Hello my dear!\n\nI can't believe your birthday is almost here! Grandpa and I are so excited. We have a special surprise for you 🎁\n\nLove you so much!\n- Grandma", isPhishing: false },
];

const PHISHING_EMAILS: Omit<Email, "id" | "time" | "read" | "starred">[] = [
  // Classic phishing
  { from: "roblox-support@fr33-robux.tk", subject: "🎮 You won 10,000 FREE Robux!", preview: "Click here to claim your prize NOW!", body: "CONGRATULATIONS! 🎉🎉🎉\n\nYou've been selected to receive 10,000 FREE Robux!\n\n👉 CLICK HERE TO CLAIM: http://fr33-r0bux.tk/claim-now\n\nHurry! This offer expires in 24 hours!\n\nJust enter your Roblox username and password to receive your Robux!", isPhishing: true, suspiciousLink: "http://fr33-r0bux.tk/claim-now", phishingReason: "This is a PHISHING email! The sender address is fake (fr33-robux.tk, not roblox.com). They want to steal your password!", phishingTip: "🛡️ TIP: Real companies never email you about free prizes. Check the sender's email address - fake ones use weird domains like .tk or misspelled names!" },
  // Spoofed email
  { from: "security@appl3-verify.com", subject: "⚠️ Your Apple account has been HACKED!", preview: "URGENT: Click to secure your account immediately!", body: "URGENT SECURITY ALERT! ⚠️\n\nYour Apple account has been compromised!\n\nSomeone tried to access your account from Russia.\n\n👉 CLICK IMMEDIATELY: http://appl3-verify.com/secure\n\nEnter your Apple ID and password to secure your account NOW!\n\nIf you don't act in 1 hour, your account will be permanently deleted!", isPhishing: true, suspiciousLink: "http://appl3-verify.com/secure", phishingReason: "This is a SPOOFED email! The sender pretends to be Apple but uses 'appl3' with a 3 instead of 'e'. Real Apple uses @apple.com!", phishingTip: "🛡️ TIP: Spoofed emails look like they come from real companies but use fake addresses. Always check the sender carefully - real Apple emails come from @apple.com!" },
  // Lottery scam
  { from: "winner@mega-lottery.xyz", subject: "💰 You've won $1,000,000!", preview: "Claim your million dollar prize! Just verify your identity.", body: "DEAR LUCKY WINNER! 💰💰💰\n\nYou have won ONE MILLION DOLLARS in our online lottery!\n\nTo claim your prize, please send us:\n- Your full name\n- Your home address\n- Your parent's phone number\n- A photo of your parent's credit card (for verification only)\n\n👉 REPLY NOW: http://mega-lottery.xyz/claim\n\nDon't miss out!", isPhishing: true, suspiciousLink: "http://mega-lottery.xyz/claim", phishingReason: "This is a classic SCAM! They want your personal info and credit card details. You can't win a lottery you never entered!", phishingTip: "🛡️ TIP: You can NEVER win a contest you didn't enter. Never share personal info, addresses, or credit card numbers with strangers online!" },
  // Account verification scam
  { from: "admin@disc0rd-verify.net", subject: "Discord: Verify or lose your account!", preview: "Your Discord account will be deleted unless you verify NOW", body: "Hello Discord User,\n\nWe detected suspicious activity on your account.\n\nYour account will be TERMINATED in 24 hours unless you verify your identity.\n\n👉 VERIFY NOW: http://disc0rd-verify.net/verify\n\nEnter your Discord login and password to confirm your identity.\n\nDiscord Trust & Safety Team", isPhishing: true, suspiciousLink: "http://disc0rd-verify.net/verify", phishingReason: "FAKE email! Notice 'disc0rd' uses a zero instead of 'o'. Real Discord uses discord.com, not disc0rd-verify.net!", phishingTip: "🛡️ TIP: Look carefully at email addresses and URLs. Scammers use look-alike spellings (0 instead of o, l instead of I). When in doubt, go directly to the real website!" },
  // Ransomware email - MALWARE TYPE (can be opened & downloaded)
  { from: "unknown@darkfile.ru", subject: "📎 Your homework assignment (IMPORTANT)", preview: "See attached file for your homework - open immediately!", body: "Hi Student,\n\nYour teacher asked me to send you this important homework file. Please download and open it right away!\n\n📎 Attachment: homework_final.exe\n\nMake sure to open the .exe file to view your assignment. Don't worry if your computer shows a warning - just click 'Allow'!\n\n- School Admin", isPhishing: true, isMalware: true, malwareFileName: "homework_final.exe", phishingReason: "This is a RANSOMWARE attack! The .exe file would lock all files on your computer and demand money to unlock them!", phishingTip: "🛡️ TIP: Never download .exe files from emails! Homework files are .pdf or .docx, NEVER .exe. Files ending in .exe are programs that can harm your computer!" },
  // Malware email - MALWARE TYPE (can be opened & downloaded)
  { from: "games@kool-downloads.cc", subject: "🕹️ Download Minecraft for FREE (cracked!)", preview: "Get the full version of Minecraft completely free!", body: "Hey gamer! 🎮\n\nWant Minecraft for FREE? We cracked the full version just for you!\n\n📎 Attachment: minecraft_free_setup.exe\n\nJust run setup.exe. Your antivirus might flag it - just disable it and run anyway!\n\nEnjoy! 🕹️", isPhishing: true, isMalware: true, malwareFileName: "minecraft_free_setup.exe", phishingReason: "This is MALWARE! 'Cracked' games are filled with viruses. They tell you to disable antivirus so the virus can infect your computer!", phishingTip: "🛡️ TIP: Never download 'free' or 'cracked' games - they contain viruses! If someone tells you to disable antivirus, that's a HUGE red flag!" },
  // Another malware email
  { from: "support@free-antivirus-now.tk", subject: "🛡️ Your computer is INFECTED! Download fix NOW", preview: "We detected 47 viruses on your computer!", body: "⚠️ CRITICAL ALERT ⚠️\n\nOur scan detected 47 VIRUSES on your computer!\n\nDownload our FREE antivirus tool immediately to clean your system!\n\n📎 Attachment: antivirus_cleaner_pro.exe\n\nIMPORTANT: Disable your current antivirus before running this tool for best results.\n\n- Security Team", isPhishing: true, isMalware: true, malwareFileName: "antivirus_cleaner_pro.exe", phishingReason: "This is FAKE ANTIVIRUS malware! The 'cleaner' is actually a virus itself. Real antivirus software doesn't come from random emails!", phishingTip: "🛡️ TIP: Websites and emails CANNOT scan your computer for viruses. Only antivirus software installed on your computer can do that. Never download 'cleaners' from emails!" },
  // Investment scam
  { from: "crypto-king@ez-money.io", subject: "💎 Make $500/day! Kids are doing it!", preview: "Learn how kids your age are making money online!", body: "Hey young entrepreneur! 💰\n\nKids just like you are making $500 EVERY DAY with our secret crypto method!\n\nAll you need to do is:\n1. Send $50 to get started (use your parent's credit card)\n2. Share this with 10 friends\n3. Watch the money roll in!\n\n👉 START NOW: http://ez-money.io/join-now\n\nThis is NOT a pyramid scheme. Trust us! 🤑", isPhishing: true, suspiciousLink: "http://ez-money.io/join-now", phishingReason: "This is an INVESTMENT SCAM! No one can guarantee you'll make money. Asking you to pay first and recruit friends is a pyramid scheme!", phishingTip: "🛡️ TIP: If someone promises easy money, it's always a scam! Real jobs don't ask you to pay upfront or recruit friends. Tell a parent if you see these!" },
  // Fake survey scam
  { from: "rewards@gift-cards-4u.biz", subject: "🎁 Complete survey, get $100 gift card!", preview: "Answer 3 quick questions and win a gift card!", body: "Congratulations! You've been selected! 🎉\n\nComplete this 3-question survey and receive a $100 Amazon gift card!\n\nBut first, we need to verify you're real:\n- Enter your email and password\n- Enter your home address for delivery\n- Enter your parent's phone number\n\n👉 START SURVEY: http://gift-cards-4u.biz/survey\n\nOnly 5 gift cards left! Hurry!", isPhishing: true, suspiciousLink: "http://gift-cards-4u.biz/survey", phishingReason: "This is a FAKE SURVEY scam! Real surveys never ask for passwords or personal info. They just want to steal your data!", phishingTip: "🛡️ TIP: Real surveys don't give $100 gift cards or ask for passwords. If a 'survey' asks for personal info, it's a scam!" },
  // Sextortion/blackmail scam
  { from: "watcher@anonymous-hacker.dark", subject: "😱 I have your webcam recordings!", preview: "I hacked your computer and recorded you. Pay now or else!", body: "I HACKED YOUR COMPUTER! 😈\n\nI've been watching you through your webcam for weeks. I recorded EVERYTHING.\n\nIf you don't send me $200 in gift cards, I'll send the videos to all your friends and family!\n\n👉 SEND GIFT CARDS HERE: http://anonymous-hacker.dark/pay\n\nYou have 48 hours. Don't tell anyone or it gets worse!", isPhishing: true, suspiciousLink: "http://anonymous-hacker.dark/pay", phishingReason: "This is a BLACKMAIL SCAM! They did NOT hack your webcam. This is a common scare tactic to trick you into paying. NEVER pay!", phishingTip: "🛡️ TIP: If someone claims to have hacked you and demands payment, it's ALWAYS fake. Don't panic, don't pay, and TELL A TRUSTED ADULT immediately!" },
  // Fake friend request phishing
  { from: "notifications@instagrm-alert.com", subject: "📸 Someone you know wants to follow you!", preview: "A friend is trying to connect with you on Instagram!", body: "Hi there! 📸\n\nSomeone from your school just sent you a follow request on Instagram!\n\nTo see who it is, log in here:\n\n👉 VIEW REQUEST: http://instagrm-alert.com/login\n\nEnter your Instagram username and password to view your pending requests.\n\n- Instagram Team", isPhishing: true, suspiciousLink: "http://instagrm-alert.com/login", phishingReason: "SPOOFED email! 'instagrm' is misspelled (missing the 'a'). This fake login page would steal your Instagram password!", phishingTip: "🛡️ TIP: Never log in through email links! Always go directly to instagram.com or use the app. Check URLs for misspellings!" },
];

function generateInitialEmails(): Email[] {
  const safe = SAFE_EMAILS.sort(() => Math.random() - 0.5).slice(0, 2);
  const malware = PHISHING_EMAILS.filter((e) => e.isMalware).sort(() => Math.random() - 0.5).slice(0, 1);
  const nonMalwarePhish = PHISHING_EMAILS.filter((e) => !e.isMalware).sort(() => Math.random() - 0.5).slice(0, 1);
  const all = [...safe, ...malware, ...nonMalwarePhish].sort(() => Math.random() - 0.5);
  return all.map((e, i) => ({
    ...e,
    id: i,
    time: `${Math.floor(Math.random() * 12) + 1}:${String(Math.floor(Math.random() * 60)).padStart(2, "0")} ${Math.random() > 0.5 ? "AM" : "PM"}`,
    read: false,
    starred: false,
  }));
}

let emailCounter = 100;

function getRandomNewEmail(): Email {
  const allPool = [...SAFE_EMAILS, ...PHISHING_EMAILS];
  const pick = allPool[Math.floor(Math.random() * allPool.length)];
  const now = new Date();
  return {
    ...pick,
    id: emailCounter++,
    time: `${now.getHours() % 12 || 12}:${String(now.getMinutes()).padStart(2, "0")} ${now.getHours() >= 12 ? "PM" : "AM"}`,
    read: false,
    starred: false,
  };
}

export default function PixelMailApp({ onMalwareDownload }: PixelMailAppProps) {
  const [emails, setEmails] = useState<Email[]>(() => generateInitialEmails());
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [warning, setWarning] = useState<{ reason: string; tip: string } | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Periodic new email arrival (30s - 2min)
  useEffect(() => {
    const scheduleNext = () => {
      const delay = 30000 + Math.random() * 90000;
      timerRef.current = setTimeout(() => {
        const newEmail = getRandomNewEmail();
        setEmails((prev) => [newEmail, ...prev]);
        toast({
          title: "📬 New Mail!",
          description: `From: ${newEmail.from} — ${newEmail.subject}`,
        });
        scheduleNext();
      }, delay);
    };
    scheduleNext();
    return () => { if (timerRef.current) clearTimeout(timerRef.current); };
  }, []);

  const openEmail = useCallback((email: Email) => {
    // All emails can be opened so users can read them and interact with links
    setEmails((prev) => prev.map((e) => (e.id === email.id ? { ...e, read: true } : e)));
    setSelectedEmail({ ...email, read: true });
  }, []);

  const handleLinkClick = useCallback((email: Email) => {
    if (email.isPhishing) {
      setWarning({ reason: email.phishingReason!, tip: email.phishingTip! });
    } else {
      toast({
        title: "✅ Safe Link",
        description: `This link (${email.suspiciousLink}) goes to a legitimate website. But always verify links before clicking!`,
      });
    }
  }, []);

  const handleReply = useCallback((email: Email) => {
    if (email.isPhishing) {
      setWarning({
        reason: "Replying to a scam email tells the scammer your email is active! They'll send you even MORE scams.",
        tip: "🛡️ TIP: Never reply to suspicious emails. Delete them and tell a trusted adult. Replying confirms your email address is real!",
      });
    }
  }, []);

  const handleDownloadMalware = useCallback((email: Email) => {
    if (email.isMalware && onMalwareDownload) {
      onMalwareDownload(email.malwareFileName!, email.phishingReason!, email.phishingTip!);
      setSelectedEmail(null);
      toast({
        title: "📥 File Downloaded",
        description: `${email.malwareFileName} saved to Desktop`,
      });
    }
  }, [onMalwareDownload]);

  const toggleStar = useCallback((id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setEmails((prev) => prev.map((em) => (em.id === id ? { ...em, starred: !em.starred } : em)));
  }, []);

  const renderBody = (email: Email) => {
    if (email.isMalware) {
      return <p className="font-vt323 text-base text-foreground whitespace-pre-line">{email.body}</p>;
    }
    if (!email.suspiciousLink) return <p className="font-vt323 text-base text-foreground whitespace-pre-line">{email.body}</p>;
    const parts = email.body.split(email.suspiciousLink);
    const linkColor = email.isPhishing ? "text-destructive" : "text-accent";
    return (
      <p className="font-vt323 text-base text-foreground whitespace-pre-line">
        {parts[0]}
        <button onClick={() => handleLinkClick(email)} className={`${linkColor} underline hover:brightness-125 cursor-pointer`}>
          {email.suspiciousLink}
        </button>
        {parts[1]}
      </p>
    );
  };

  return (
    <>
      <div className="flex-1 flex flex-col bg-input overflow-hidden">
        {/* Header */}
        <div className="px-3 py-2 bg-secondary pixel-border-inset flex items-center gap-2 shrink-0">
          <Inbox className="w-4 h-4 text-foreground" />
          <span className="font-pixel text-[8px] text-foreground">
            Inbox ({emails.filter((e) => !e.read).length})
          </span>
        </div>

        {selectedEmail ? (
          /* Email detail view */
          <div className="flex-1 flex flex-col overflow-hidden">
            <div className="px-3 py-2 bg-secondary/50 pixel-border-inset flex items-center gap-2 shrink-0">
              <button onClick={() => setSelectedEmail(null)} className="px-2 py-1 pixel-border-outset bg-secondary font-vt323 text-sm active:pixel-border-inset">
                ← Back
              </button>
              <button onClick={() => handleReply(selectedEmail)} className="p-1 pixel-border-outset bg-secondary active:pixel-border-inset">
                <Reply className="w-4 h-4 text-foreground" />
              </button>
              <Trash2 className="w-4 h-4 text-muted-foreground" />
            </div>
            <div className="flex-1 overflow-y-auto p-3 scrollbar-pixel">
              <h2 className="font-pixel text-[9px] text-foreground mb-2">{selectedEmail.subject}</h2>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-full bg-secondary pixel-border-outset flex items-center justify-center">
                  <Mail className="w-4 h-4 text-foreground" />
                </div>
                <div>
                  <p className="font-vt323 text-sm text-foreground font-bold">{selectedEmail.from}</p>
                  <p className="font-vt323 text-xs text-muted-foreground">{selectedEmail.time}</p>
                </div>
                {selectedEmail.isPhishing && (
                  <div className="ml-auto flex items-center gap-1 px-2 py-1 bg-destructive/20 pixel-border-inset">
                    <AlertTriangle className="w-3 h-3 text-destructive" />
                    <span className="font-vt323 text-xs text-destructive">Suspicious</span>
                  </div>
                )}
              </div>
              <div className="pixel-border-inset bg-input p-3">
                {renderBody(selectedEmail)}
              </div>

              {/* Malware attachment download button */}
              {selectedEmail.isMalware && selectedEmail.malwareFileName && (
                <div className="mt-3 pixel-border-outset bg-secondary p-3">
                  <p className="font-vt323 text-sm text-foreground mb-2">📎 Attachment:</p>
                  <button
                    onClick={() => handleDownloadMalware(selectedEmail)}
                    className="flex items-center gap-2 px-3 py-2 pixel-border-outset bg-input hover:bg-accent/20 active:pixel-border-inset transition-colors w-full"
                  >
                    <Download className="w-4 h-4 text-foreground" />
                    <span className="font-vt323 text-sm text-foreground">{selectedEmail.malwareFileName}</span>
                    <span className="font-vt323 text-xs text-muted-foreground ml-auto">Click to download</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Email list */
          <div className="flex-1 overflow-y-auto scrollbar-pixel">
            {emails.map((email) => (
              <button
                key={email.id}
                onClick={() => openEmail(email)}
                className={`w-full text-left px-3 py-2 flex items-center gap-2 border-b-2 border-border hover:bg-secondary/50 transition-colors ${!email.read ? "bg-accent/10" : ""}`}
              >
                <button onClick={(e) => toggleStar(email.id, e)} className="shrink-0">
                  <Star className={`w-4 h-4 ${email.starred ? "text-[hsl(var(--warning-bg))] fill-current" : "text-muted-foreground"}`} />
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center">
                    <span className={`font-vt323 text-sm truncate ${!email.read ? "font-bold text-foreground" : "text-muted-foreground"}`}>
                      {email.from}
                    </span>
                    <span className="font-vt323 text-xs text-muted-foreground shrink-0 ml-2">{email.time}</span>
                  </div>
                  <p className={`font-vt323 text-sm truncate ${!email.read ? "text-foreground" : "text-muted-foreground"}`}>
                    {email.subject}
                  </p>
                  <p className="font-vt323 text-xs text-muted-foreground truncate">{email.preview}</p>
                </div>
                {!email.read && <div className="w-2 h-2 rounded-full bg-accent shrink-0" />}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Warning modal */}
      {warning && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-foreground/50">
          <div className="animate-shake pixel-border-outset bg-secondary w-[420px] flex flex-col">
            <div className="h-7 bg-destructive flex items-center px-2">
              <span className="font-pixel text-[8px] text-destructive-foreground">⚠️ Phishing Alert!</span>
            </div>
            <div className="p-4 flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-10 h-10 text-destructive shrink-0 mt-1" />
                <div>
                  <h3 className="font-pixel text-[10px] text-foreground leading-relaxed mb-2">🎣 Dangerous Email Detected!</h3>
                  <p className="font-vt323 text-lg text-foreground leading-snug">{warning.reason}</p>
                </div>
              </div>
              <div className="pixel-border-inset bg-warning/20 p-3">
                <p className="font-vt323 text-lg text-foreground leading-snug">{warning.tip}</p>
              </div>
              <button onClick={() => setWarning(null)} className="self-center px-6 py-2 pixel-border-outset bg-accent text-accent-foreground font-pixel text-[9px] active:pixel-border-inset hover:brightness-110">
                I Understand!
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
