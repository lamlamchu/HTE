import { MessageSquare, Globe, Mail, FileWarning, Search } from "lucide-react";

interface DesktopIconProps {
  icon: 'chat' | 'facebook' | 'mail' | 'malware' | 'factcheck';
  label: string;
  onClick: () => void;
  isActive?: boolean;
}

const iconMap = {
  chat: MessageSquare,
  facebook: Globe,
  mail: Mail,
  malware: FileWarning,
  factcheck: Search,
};

const colorMap = {
  chat: 'text-accent',
  facebook: 'text-accent',
  mail: 'text-warning',
  malware: 'text-destructive',
  factcheck: 'text-accent',
};

export default function DesktopIcon({ icon, label, onClick, isActive }: DesktopIconProps) {
  const Icon = iconMap[icon];

  return (
    <button
      onClick={onClick}
      onDoubleClick={onClick}
      className={`
        flex flex-col items-center gap-1 p-2 w-20
        hover:bg-accent/20 focus:bg-accent/30
        transition-none select-none
        ${isActive ? 'bg-accent/30' : ''}
      `}
    >
      <div className={`w-12 h-12 flex items-center justify-center pixel-border-outset ${icon === 'malware' ? 'bg-destructive/20' : 'bg-secondary'}`}>
        <Icon className={`w-8 h-8 ${colorMap[icon]}`} />
      </div>
      <span className="font-pixel text-[8px] text-primary-foreground text-center leading-tight drop-shadow-[1px_1px_0_rgba(0,0,0,0.8)]">
        {label}
      </span>
    </button>
  );
}
