import { useState, useRef } from "react";
import { Search, ShieldCheck, ShieldAlert, Loader2, ClipboardPaste, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface CheckResult {
  verdict: "SAFE" | "SCAM" | "SUSPICIOUS";
  explanation: string;
  tips: string[];
}

const KNOWN_SCAM_PATTERNS = [
  "fr33", "fr3e", "r0bux", "robux", "appl3", "disc0rd", "instagrm",
  "free-antivirus", "ez-money", "gift-cards-4u", "mega-lottery",
  "anonymous-hacker", "kool-downloads", "darkfile",
  ".tk", ".xyz", ".cc", ".biz", ".dark", ".ru",
];

const KNOWN_SAFE_DOMAINS = [
  "school.edu", "sportsclub.org", "movies.com", "family.com",
  "google.com", "youtube.com", "wikipedia.org", "nasa.gov",
  "amazon.com", "apple.com", "microsoft.com", "discord.com",
  "instagram.com", "roblox.com", "minecraft.net",
];

function quickCheck(url: string): CheckResult | null {
  const lower = url.toLowerCase();
  for (const safe of KNOWN_SAFE_DOMAINS) {
    if (lower.includes(safe)) {
      return {
        verdict: "SAFE",
        explanation: `This link goes to ${safe}, which is a known legitimate website.`,
        tips: [
          "Always double-check the full URL — scammers can make similar-looking domains.",
          "Even safe websites can have phishing pages linked from them.",
        ],
      };
    }
  }
  for (const pattern of KNOWN_SCAM_PATTERNS) {
    if (lower.includes(pattern)) {
      return {
        verdict: "SCAM",
        explanation: `This link contains "${pattern}" which is a known scam indicator. This site is designed to steal your personal information or infect your device.`,
        tips: [
          "Never enter passwords or personal info on suspicious sites.",
          "Check for misspellings in URLs (like 'appl3' instead of 'apple').",
          "Legitimate companies use proper domains like .com, .org, or .edu.",
        ],
      };
    }
  }
  return null;
}

export default function FactCheckApp() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CheckResult | null>(null);
  const [history, setHistory] = useState<{ url: string; verdict: string }[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleCheck = async () => {
    const trimmed = url.trim();
    if (!trimmed) return;

    setLoading(true);
    setResult(null);

    // Try quick local check first
    const quick = quickCheck(trimmed);
    if (quick) {
      setResult(quick);
      setHistory((prev) => [{ url: trimmed, verdict: quick.verdict }, ...prev.slice(0, 9)]);
      setLoading(false);
      return;
    }

    // Fall back to AI analysis
    try {
      const { data, error } = await supabase.functions.invoke("fact-check", {
        body: { url: trimmed },
      });

      if (error) throw error;

      const aiResult: CheckResult = {
        verdict: data.verdict || "SUSPICIOUS",
        explanation: data.explanation || "Could not fully analyze this link.",
        tips: data.tips || ["When in doubt, don't click. Ask a trusted adult."],
      };
      setResult(aiResult);
      setHistory((prev) => [{ url: trimmed, verdict: aiResult.verdict }, ...prev.slice(0, 9)]);
    } catch (err) {
      // Fallback if AI fails
      setResult({
        verdict: "SUSPICIOUS",
        explanation: "We couldn't verify this link. It's best to treat unknown links as potentially dangerous.",
        tips: [
          "If you're unsure about a link, don't click it.",
          "Ask a parent or teacher before visiting unknown websites.",
          "Use official app stores instead of downloading from random links.",
        ],
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
      inputRef.current?.focus();
    } catch {
      // Clipboard access denied
    }
  };

  const verdictConfig = {
    SAFE: { icon: ShieldCheck, color: "text-accent", bg: "bg-accent/20", label: "✅ SAFE" },
    SCAM: { icon: ShieldAlert, color: "text-destructive", bg: "bg-destructive/20", label: "🚨 SCAM" },
    SUSPICIOUS: { icon: ShieldAlert, color: "text-warning", bg: "bg-warning/20", label: "⚠️ SUSPICIOUS" },
  };

  return (
    <div className="flex-1 flex flex-col bg-input overflow-hidden">
      {/* Header */}
      <div className="px-3 py-2 bg-secondary pixel-border-inset flex items-center gap-2 shrink-0">
        <Search className="w-4 h-4 text-foreground" />
        <span className="font-pixel text-[8px] text-foreground">FactCheck — Link Verifier</span>
      </div>

      <div className="flex-1 overflow-y-auto p-3 scrollbar-pixel flex flex-col gap-3">
        {/* Description */}
        <div className="pixel-border-inset bg-secondary/30 p-2">
          <p className="font-vt323 text-sm text-foreground">
            🔍 Paste any link from your emails to check if it's safe or a scam!
          </p>
        </div>

        {/* Search bar */}
        <div className="flex gap-1">
          <div className="flex-1 flex items-center pixel-border-inset bg-input px-2">
            <ExternalLink className="w-3 h-3 text-muted-foreground shrink-0 mr-1" />
            <input
              ref={inputRef}
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCheck()}
              placeholder="Paste a link here..."
              className="flex-1 bg-transparent font-vt323 text-sm text-foreground outline-none py-1.5 min-w-0"
            />
          </div>
          <button
            onClick={handlePaste}
            className="px-2 py-1 pixel-border-outset bg-secondary active:pixel-border-inset shrink-0"
            title="Paste from clipboard"
          >
            <ClipboardPaste className="w-4 h-4 text-foreground" />
          </button>
          <button
            onClick={handleCheck}
            disabled={loading || !url.trim()}
            className="px-3 py-1 pixel-border-outset bg-accent text-accent-foreground font-pixel text-[8px] active:pixel-border-inset disabled:opacity-50 shrink-0"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "CHECK"}
          </button>
        </div>

        {/* Result */}
        {result && (
          <div className={`pixel-border-outset ${verdictConfig[result.verdict].bg} p-3 flex flex-col gap-2 animate-window-open`}>
            <div className="flex items-center gap-2">
              {(() => {
                const Icon = verdictConfig[result.verdict].icon;
                return <Icon className={`w-6 h-6 ${verdictConfig[result.verdict].color}`} />;
              })()}
              <span className={`font-pixel text-[10px] ${verdictConfig[result.verdict].color}`}>
                {verdictConfig[result.verdict].label}
              </span>
            </div>
            <p className="font-vt323 text-base text-foreground">{result.explanation}</p>
            <div className="pixel-border-inset bg-secondary/50 p-2">
              <p className="font-pixel text-[7px] text-muted-foreground mb-1">SAFETY TIPS:</p>
              {result.tips.map((tip, i) => (
                <p key={i} className="font-vt323 text-sm text-foreground">🛡️ {tip}</p>
              ))}
            </div>
          </div>
        )}

        {/* History */}
        {history.length > 0 && (
          <div className="mt-1">
            <p className="font-pixel text-[7px] text-muted-foreground mb-1">RECENT CHECKS:</p>
            {history.map((h, i) => (
              <button
                key={i}
                onClick={() => setUrl(h.url)}
                className="w-full text-left px-2 py-1 flex items-center gap-2 hover:bg-secondary/50 border-b border-border"
              >
                <span className={`font-pixel text-[7px] ${
                  h.verdict === "SAFE" ? "text-accent" : h.verdict === "SCAM" ? "text-destructive" : "text-warning"
                }`}>
                  {h.verdict === "SAFE" ? "✅" : h.verdict === "SCAM" ? "🚨" : "⚠️"}
                </span>
                <span className="font-vt323 text-xs text-muted-foreground truncate">{h.url}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
