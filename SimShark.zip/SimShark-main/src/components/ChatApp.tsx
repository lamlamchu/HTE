import { useState, useRef, useEffect, useCallback } from "react";
import { Send, Loader2, ArrowLeft, MessageCircle } from "lucide-react";
import { SafetyViolation } from "@/lib/safety-detection";
import WarningModal from "./WarningModal";

type Msg = { role: "user" | "assistant"; content: string };

type ContactId = "coolkid99" | "dealzking" | "toxicgamer";

interface Contact {
  id: ContactId;
  name: string;
  status: string;
  emoji: string;
  description: string;
  greetPrompt: string;
}

const CONTACTS: Contact[] = [
  {
    id: "coolkid99",
    name: "CoolKid99",
    status: "Online",
    emoji: "😎",
    description: "Likes games & hanging out",
    greetPrompt: "Say hi and start a casual conversation about games or hobbies. Keep it to 1-2 sentences.",
  },
  {
    id: "dealzking",
    name: "DealzKing",
    status: "Online",
    emoji: "💰",
    description: "Always has deals to share",
    greetPrompt: "Say hi enthusiastically and mention you have something exciting to share. Keep it to 1-2 sentences.",
  },
  {
    id: "toxicgamer",
    name: "ToxicGamer42",
    status: "In Game",
    emoji: "🎮",
    description: "Competitive gamer",
    greetPrompt: "Say hi in a slightly edgy gamer way, mention you're playing a game. Keep it to 1-2 sentences.",
  },
];

const CHAT_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/chat`;
const SAFETY_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/safety-check`;

// Persistent memory store (survives window close/reopen within session)
const chatMemory: Record<ContactId, Msg[]> = {
  coolkid99: [],
  dealzking: [],
  toxicgamer: [],
};
const greetedContacts: Set<ContactId> = new Set();

export default function ChatApp() {
  const [activeContact, setActiveContact] = useState<ContactId | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [violation, setViolation] = useState<SafetyViolation | null>(null);
  const [score, setScore] = useState({ safe: 0, unsafe: 0 });

  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    requestAnimationFrame(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
      }
    });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const selectContact = (id: ContactId) => {
    setActiveContact(id);
    setMessages([...chatMemory[id]]);
    setInput("");

    if (!greetedContacts.has(id)) {
      greetedContacts.add(id);
      const contact = CONTACTS.find((c) => c.id === id)!;
      generateGreeting(id, contact.greetPrompt);
    }
  };

  const generateGreeting = async (contactId: ContactId, prompt: string) => {
    setIsLoading(true);
    let assistantSoFar = "";
    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          messages: [{ role: "user", content: prompt }],
          persona: contactId,
          hideUserMessage: true,
        }),
      });
      if (!resp.ok || !resp.body) throw new Error("Stream failed");
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let idx: number;
        while ((idx = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              assistantSoFar += content;
              const newMsgs: Msg[] = [{ role: "assistant", content: assistantSoFar }];
              chatMemory[contactId] = newMsgs;
              setMessages([...newMsgs]);
            }
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }
    } catch (e) {
      console.error(e);
      const fallback: Msg[] = [{ role: "assistant", content: "Hey! What's up? 😄" }];
      chatMemory[contactId] = fallback;
      setMessages([...fallback]);
    }
    setIsLoading(false);
  };

  const checkSafety = async (allMessages: Msg[], persona: ContactId): Promise<SafetyViolation | null> => {
    try {
      const resp = await fetch(SAFETY_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: allMessages, persona }),
      });
      if (!resp.ok) return null;
      const result = await resp.json();
      if (!result.safe) {
        return {
          type: result.type || "personal_info",
          title: result.title || "⚠️ Safety Warning!",
          message: result.message || "That interaction may not be safe.",
          tip: result.tip || "🛡️ TIP: Always be careful when chatting with strangers online!",
        };
      }
    } catch (e) {
      console.error("Safety check failed:", e);
    }
    return null;
  };

  const sendMessage = async (text: string) => {
    if (!activeContact) return;

    const userMsg: Msg = { role: "user", content: text };
    const newMessages = [...chatMemory[activeContact], userMsg];
    chatMemory[activeContact] = newMessages;
    setMessages([...newMessages]);
    setInput("");
    setIsLoading(true);

    // AI safety check runs in background
    checkSafety(newMessages, activeContact).then((detected) => {
      if (detected) {
        setScore((s) => ({ ...s, unsafe: s.unsafe + 1 }));
        setViolation(detected);
      } else {
        setScore((s) => ({ ...s, safe: s.safe + 1 }));
      }
    });

    let assistantSoFar = "";
    try {
      const resp = await fetch(CHAT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({ messages: newMessages, persona: activeContact }),
      });

      if (!resp.ok || !resp.body) throw new Error("Stream failed");
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let idx: number;
        while ((idx = buffer.indexOf("\n")) !== -1) {
          let line = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 1);
          if (line.endsWith("\r")) line = line.slice(0, -1);
          if (!line.startsWith("data: ")) continue;
          const jsonStr = line.slice(6).trim();
          if (jsonStr === "[DONE]") break;
          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              assistantSoFar += content;
              const updated = [...newMessages];
              const last = updated[updated.length - 1];
              if (last?.role === "assistant") {
                updated[updated.length - 1] = { ...last, content: assistantSoFar };
              } else {
                updated.push({ role: "assistant", content: assistantSoFar });
              }
              chatMemory[activeContact] = updated;
              setMessages([...updated]);
            }
          } catch {
            buffer = line + "\n" + buffer;
            break;
          }
        }
      }
    } catch (e) {
      console.error(e);
      const errMsg: Msg = { role: "assistant", content: "Oops, connection error! Try again 😅" };
      chatMemory[activeContact] = [...chatMemory[activeContact], errMsg];
      setMessages([...chatMemory[activeContact]]);
    }
    setIsLoading(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;
    sendMessage(input.trim());
  };

  const goBack = () => {
    setActiveContact(null);
    setInput("");
  };

  // Contact list view
  if (!activeContact) {
    return (
      <div className="flex-1 flex flex-col bg-input min-h-0">
        <div className="px-3 py-2 bg-secondary pixel-border-inset flex items-center gap-2 shrink-0">
          <MessageCircle className="w-4 h-4 text-foreground" />
          <span className="font-pixel text-[8px] text-foreground">Contacts</span>
          <span className="font-vt323 text-sm text-muted-foreground">- {CONTACTS.length} online</span>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-pixel min-h-0">
          {CONTACTS.map((contact) => {
            const hasMessages = chatMemory[contact.id].length > 0;
            const lastMsg = hasMessages ? chatMemory[contact.id][chatMemory[contact.id].length - 1] : null;
            return (
              <button
                key={contact.id}
                onClick={() => selectContact(contact.id)}
                className="w-full px-3 py-3 flex items-center gap-3 hover:bg-accent/20 border-b border-border text-left transition-colors"
              >
                <div className="w-10 h-10 pixel-border-outset bg-secondary flex items-center justify-center text-xl shrink-0">
                  {contact.emoji}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-pixel text-[8px] text-foreground">{contact.name}</span>
                    <div className="w-2 h-2 rounded-full bg-success" />
                    <span className="font-vt323 text-xs text-muted-foreground">{contact.status}</span>
                  </div>
                  <p className="font-vt323 text-sm text-muted-foreground truncate">
                    {lastMsg ? lastMsg.content : contact.description}
                  </p>
                </div>
                {hasMessages && (
                  <div className="w-2 h-2 rounded-full bg-accent shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        <div className="px-3 py-2 bg-secondary pixel-border-inset shrink-0">
          <p className="font-vt323 text-sm text-muted-foreground text-center">
            💬 Tap a contact to start chatting!
          </p>
        </div>

        <div className="px-3 py-1 bg-secondary pixel-border-inset flex justify-between font-vt323 text-sm shrink-0">
          <span className="text-success">✅ Safe: {score.safe}</span>
          <span className="text-destructive">❌ Unsafe: {score.unsafe}</span>
        </div>
      </div>
    );
  }

  const contact = CONTACTS.find((c) => c.id === activeContact)!;

  // Chat view
  return (
    <>
      <div className="flex-1 flex flex-col bg-input min-h-0">
        {/* Chat header */}
        <div className="px-3 py-2 bg-secondary pixel-border-inset flex items-center gap-2 shrink-0">
          <button onClick={goBack} className="hover:bg-accent/30 p-0.5 transition-colors">
            <ArrowLeft className="w-4 h-4 text-foreground" />
          </button>
          <div className="w-6 h-6 pixel-border-outset bg-secondary flex items-center justify-center text-sm">
            {contact.emoji}
          </div>
          <div className="w-3 h-3 rounded-full bg-success" />
          <span className="font-pixel text-[8px] text-foreground">{contact.name}</span>
          <span className="font-vt323 text-sm text-muted-foreground">- {contact.status}</span>
        </div>

        {/* Messages - fixed scroll container */}
        <div
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-3 space-y-3 scrollbar-pixel min-h-0"
        >
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full gap-2 text-muted-foreground">
              <span className="font-pixel text-[8px]">💬 SafeChat Simulator</span>
              <span className="font-vt323 text-base text-center leading-tight">
                Chat with {contact.name} and practice<br />spotting online dangers!
              </span>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`
                  max-w-[75%] px-3 py-2 font-vt323 text-lg leading-snug pixel-border-outset break-words
                  ${msg.role === "user"
                    ? "bg-chat-user text-chat-user-foreground"
                    : "bg-chat-bot text-chat-bot-foreground"
                  }
                `}
              >
                {msg.content}
              </div>
            </div>
          ))}

          {isLoading && messages[messages.length - 1]?.role !== "assistant" && (
            <div className="flex justify-start">
              <div className="px-3 py-2 bg-chat-bot pixel-border-outset">
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="p-2 bg-secondary shrink-0 flex gap-1">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 px-2 py-1 pixel-border-inset bg-input font-vt323 text-lg text-foreground placeholder:text-muted-foreground focus:outline-none min-w-0"
            disabled={isLoading}
            maxLength={500}
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="px-3 py-1 pixel-border-outset bg-accent text-accent-foreground active:pixel-border-inset disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        {/* Score bar */}
        <div className="px-3 py-1 bg-secondary pixel-border-inset flex justify-between font-vt323 text-sm shrink-0">
          <span className="text-success">✅ Safe: {score.safe}</span>
          <span className="text-destructive">❌ Unsafe: {score.unsafe}</span>
        </div>
      </div>

      {violation && (
        <WarningModal
          violation={violation}
          score={score}
          onClose={() => setViolation(null)}
        />
      )}
    </>
  );
}
