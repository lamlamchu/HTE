import { SafetyViolation } from "@/lib/safety-detection";
import { ShieldAlert } from "lucide-react";

interface WarningModalProps {
  violation: SafetyViolation;
  onClose: () => void;
  score: { safe: number; unsafe: number };
}

export default function WarningModal({ violation, onClose, score }: WarningModalProps) {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-foreground/50">
      <div className="animate-shake pixel-border-outset bg-secondary w-[420px] flex flex-col">
        {/* Title bar */}
        <div className="h-7 bg-destructive flex items-center px-2">
          <span className="font-pixel text-[8px] text-destructive-foreground">
            ⚠️ Safety Warning
          </span>
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col gap-4">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-10 h-10 text-destructive shrink-0 mt-1" />
            <div>
              <h3 className="font-pixel text-[10px] text-foreground leading-relaxed mb-2">
                {violation.title}
              </h3>
              <p className="font-vt323 text-lg text-foreground leading-snug">
                {violation.message}
              </p>
            </div>
          </div>

          <div className="pixel-border-inset bg-warning/20 p-3">
            <p className="font-vt323 text-lg text-foreground leading-snug">
              {violation.tip}
            </p>
          </div>

          <div className="pixel-border-inset bg-input p-2 flex justify-between font-vt323 text-base">
            <span className="text-success">✅ Safe choices: {score.safe}</span>
            <span className="text-destructive">❌ Unsafe choices: {score.unsafe}</span>
          </div>

          <button
            onClick={onClose}
            className="self-center px-6 py-2 pixel-border-outset bg-accent text-accent-foreground font-pixel text-[9px] active:pixel-border-inset hover:brightness-110"
          >
            I Understand!
          </button>
        </div>
      </div>
    </div>
  );
}
