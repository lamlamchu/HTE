import { useState, useEffect } from "react";
import { ShieldAlert, Bug, Skull, AlertTriangle } from "lucide-react";

interface VirusEffectProps {
  fileName: string;
  reason: string;
  tip: string;
  onDismiss: () => void;
}

const VIRUS_MESSAGES = [
  "INSTALLING MALWARE...",
  "ACCESSING PERSONAL FILES...",
  "STEALING PASSWORDS...",
  "ENCRYPTING DOCUMENTS...",
  "SENDING DATA TO HACKERS...",
  "DISABLING ANTIVIRUS...",
  "CORRUPTING SYSTEM FILES...",
  "UPLOADING CONTACTS...",
  "ACTIVATING KEYLOGGER...",
  "SYSTEM COMPROMISED!",
];

export default function VirusEffect({ fileName, reason, tip, onDismiss }: VirusEffectProps) {
  const [phase, setPhase] = useState<"infecting" | "warning">("infecting");
  const [msgIndex, setMsgIndex] = useState(0);
  const [popups, setPopups] = useState<{ id: number; x: number; y: number; msg: string }[]>([]);

  // Cycle through virus messages
  useEffect(() => {
    if (phase !== "infecting") return;
    const interval = setInterval(() => {
      setMsgIndex((prev) => {
        if (prev >= VIRUS_MESSAGES.length - 1) {
          clearInterval(interval);
          setTimeout(() => setPhase("warning"), 600);
          return prev;
        }
        return prev + 1;
      });
    }, 400);
    return () => clearInterval(interval);
  }, [phase]);

  // Spawn random error popups during infection
  useEffect(() => {
    if (phase !== "infecting") return;
    let counter = 0;
    const interval = setInterval(() => {
      const newPopup = {
        id: counter++,
        x: 10 + Math.random() * 70,
        y: 10 + Math.random() * 60,
        msg: ["ERROR!", "ACCESS DENIED", "FILE CORRUPTED", "VIRUS DETECTED", "SYSTEM ERROR", "WARNING!"][Math.floor(Math.random() * 6)],
      };
      setPopups((prev) => [...prev.slice(-12), newPopup]);
    }, 200);
    return () => clearInterval(interval);
  }, [phase]);

  if (phase === "infecting") {
    return (
      <div className="fixed inset-0 z-[200] bg-foreground overflow-hidden">
        {/* Glitch scanlines */}
        <div className="absolute inset-0 opacity-30" style={{
          background: "repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,0,0.1) 2px, rgba(0,255,0,0.1) 4px)",
        }} />

        {/* Center console */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
          <Skull className="w-20 h-20 text-destructive animate-pulse" />
          <p className="font-pixel text-[12px] text-destructive animate-pulse">
            ☠️ VIRUS ACTIVATED ☠️
          </p>
          <p className="font-vt323 text-2xl text-[hsl(120,100%,50%)]">
            {VIRUS_MESSAGES[msgIndex]}
          </p>
          <div className="w-64 h-4 pixel-border-inset bg-secondary mt-2">
            <div
              className="h-full bg-destructive transition-all duration-300"
              style={{ width: `${((msgIndex + 1) / VIRUS_MESSAGES.length) * 100}%` }}
            />
          </div>
          <p className="font-vt323 text-lg text-muted-foreground mt-2">
            Running: {fileName}
          </p>
        </div>

        {/* Random error popups */}
        {popups.map((p) => (
          <div
            key={p.id}
            className="absolute pixel-border-outset bg-secondary flex flex-col animate-shake"
            style={{ left: `${p.x}%`, top: `${p.y}%`, minWidth: 140 }}
          >
            <div className="h-5 bg-destructive flex items-center px-1">
              <span className="font-pixel text-[6px] text-destructive-foreground">⚠️ Error</span>
            </div>
            <div className="p-2 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-destructive shrink-0" />
              <span className="font-vt323 text-sm text-foreground">{p.msg}</span>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Warning phase
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-foreground/80">
      <div className="pixel-border-outset bg-secondary w-[460px] flex flex-col animate-window-open">
        <div className="h-7 bg-destructive flex items-center px-2">
          <span className="font-pixel text-[8px] text-destructive-foreground">
            ☠️ MALWARE WARNING — Your Computer Was Infected!
          </span>
        </div>
        <div className="p-4 flex flex-col gap-4">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-12 h-12 text-destructive shrink-0 mt-1" />
            <div>
              <h3 className="font-pixel text-[10px] text-foreground leading-relaxed mb-2">
                🦠 You Downloaded Malware!
              </h3>
              <p className="font-vt323 text-lg text-foreground leading-snug">
                You opened <span className="text-destructive font-bold">{fileName}</span> and it infected your computer!
              </p>
            </div>
          </div>

          <div className="pixel-border-inset bg-destructive/10 p-3">
            <p className="font-vt323 text-lg text-foreground leading-snug">
              <Bug className="w-4 h-4 inline text-destructive mr-1" />
              {reason}
            </p>
          </div>

          <div className="pixel-border-inset bg-warning/20 p-3">
            <p className="font-vt323 text-lg text-foreground leading-snug">{tip}</p>
          </div>

          <p className="font-vt323 text-base text-muted-foreground text-center">
            Don't worry — this was just a simulation! Your real computer is safe. 😊
          </p>

          <button
            onClick={onDismiss}
            className="self-center px-6 py-2 pixel-border-outset bg-accent text-accent-foreground font-pixel text-[9px] active:pixel-border-inset hover:brightness-110"
          >
            I Understand!
          </button>
        </div>
      </div>
    </div>
  );
}
