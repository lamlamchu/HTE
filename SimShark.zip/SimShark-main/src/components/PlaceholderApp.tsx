import { Construction } from "lucide-react";

interface PlaceholderAppProps {
  name: string;
}

export default function PlaceholderApp({ name }: PlaceholderAppProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center gap-3 bg-input p-6">
      <Construction className="w-12 h-12 text-muted-foreground" />
      <p className="font-pixel text-[9px] text-foreground text-center leading-relaxed">
        {name}
      </p>
      <p className="font-vt323 text-lg text-muted-foreground text-center">
        This app is coming soon!<br />
        Try the Chat app to practice<br />
        online safety skills. 🛡️
      </p>
    </div>
  );
}
