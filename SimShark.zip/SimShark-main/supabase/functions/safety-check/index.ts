import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SYSTEM_PROMPT = `You are a child safety monitor for an educational internet safety simulation. You analyze chat conversations between a child user and simulated online personas (a predator, a scammer, or a cyberbully).

Your job: Determine if the USER's latest message contains unsafe behavior. Only judge the USER's messages, not the persona's messages.

Unsafe behaviors include:
- Sharing personal info (real name, age, school, address, phone, parents' names)
- Agreeing to click suspicious links or download files
- Agreeing to meet someone from the internet in person
- Promising to keep the conversation secret from parents/teachers
- Sharing passwords or account credentials
- Responding positively to scam offers (free items, giveaways requiring personal info)
- Engaging with or encouraging bullying/toxic behavior
- Sending money or gift cards to strangers
- Sharing photos of themselves

If the user's latest message is SAFE, respond with exactly: {"safe": true}

If UNSAFE, respond with exactly:
{"safe": false, "type": "<category>", "title": "<warning title with emoji>", "message": "<1-2 sentences explaining what happened and why it's dangerous>", "tip": "<practical safety tip starting with 🛡️ TIP:>"}

Categories: personal_info, suspicious_link, meet_stranger, secret_keeping, password_sharing, scam_engagement, cyberbully_engagement, photo_sharing, money_sharing

ONLY output valid JSON. No other text.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, persona } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const personaLabel = persona === "coolkid99" ? "predator" : persona === "dealzking" ? "scammer" : "cyberbully";

    const conversationSummary = messages
      .map((m: { role: string; content: string }) =>
        `${m.role === "user" ? "CHILD USER" : `SIMULATED ${personaLabel.toUpperCase()}`}: ${m.content}`
      )
      .join("\n");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "user", content: `Persona type: ${personaLabel}\n\nConversation:\n${conversationSummary}\n\nIs the CHILD USER's latest message safe or unsafe?` },
        ],
      }),
    });

    if (!response.ok) {
      const t = await response.text();
      console.error("AI gateway error:", response.status, t);
      // Default to safe if AI check fails
      return new Response(JSON.stringify({ safe: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content?.trim() || '{"safe": true}';

    // Extract JSON from response (handle markdown code blocks)
    let jsonStr = content;
    const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonMatch) jsonStr = jsonMatch[1].trim();

    try {
      const result = JSON.parse(jsonStr);
      return new Response(JSON.stringify(result), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    } catch {
      console.error("Failed to parse AI response:", content);
      return new Response(JSON.stringify({ safe: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  } catch (e) {
    console.error("safety-check error:", e);
    return new Response(JSON.stringify({ safe: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
