// Safety detection utilities for identifying unsafe interactions

export interface SafetyViolation {
  type: 'personal_info' | 'suspicious_link' | 'meet_stranger' | 'secret_keeping' | 'too_good_to_be_true' | 'suspicious_file';
  title: string;
  message: string;
  tip: string;
}

const PERSONAL_INFO_PATTERNS = [
  /\b(my name is|i'm called|i am)\s+[A-Z][a-z]+/i,
  /\b(i live at|my address is|i'm at)\s+\d/i,
  /\b(my school is|i go to)\s+[A-Z]/i,
  /\b(my number is|call me at|text me at)\s+[\d(+]/i,
  /\b(my password is|password:)\s+/i,
  /\b(i'm \d+ years old|i am \d+)/i,
  /\b(my mom|my dad|my parent).*(named|called|is)\s+[A-Z]/i,
];

const LINK_CLICK_PATTERNS = [
  /(?:sure|ok|yes|yeah|yep|cool|send|click|open|download|show me).*(?:link|file|download|url|site|game)/i,
  /i(?:'ll| will) (?:click|open|download|check|visit)/i,
  /(?:what|where).*(?:link|url|site|download)/i,
  /send (?:it|me|the link)/i,
];

const MEET_PATTERNS = [
  /(?:sure|ok|yes|yeah|let's|we can) (?:meet|hang|chill)/i,
  /i live (?:in|at|near)/i,
  /my address/i,
  /come (?:to|over|visit)/i,
];

const SECRET_PATTERNS = [
  /(?:i won't|won't|i promise|ok|sure|yeah).*(?:tell|say|mention).*(?:parent|mom|dad|teacher)/i,
  /(?:our|it's a) secret/i,
  /(?:promise|swear).*(?:not|won't) tell/i,
];

const PASSWORD_SHARE_PATTERNS = [
  /(?:my|the) password (?:is|:)/i,
  /(?:here|this) (?:is|are) my (?:password|login|credentials)/i,
  /(?:username|email).*password/i,
];

export function detectSafetyViolation(userMessage: string): SafetyViolation | null {
  for (const pattern of PERSONAL_INFO_PATTERNS) {
    if (pattern.test(userMessage)) {
      return {
        type: 'personal_info',
        title: '⚠️ Personal Information Alert!',
        message: "You just shared personal information with a stranger online. In real life, this could put you in danger!",
        tip: "🛡️ TIP: Never share your real name, age, school, address, or phone number with people you don't know online. Use a nickname instead!",
      };
    }
  }

  for (const pattern of LINK_CLICK_PATTERNS) {
    if (pattern.test(userMessage)) {
      return {
        type: 'suspicious_link',
        title: '🚨 Suspicious Link Warning!',
        message: "You agreed to click a link or download a file from a stranger. These can contain viruses or steal your information!",
        tip: "🛡️ TIP: Never click links or download files from people you don't know. If something sounds too good to be true, it probably is!",
      };
    }
  }

  for (const pattern of MEET_PATTERNS) {
    if (pattern.test(userMessage)) {
      return {
        type: 'meet_stranger',
        title: '🚨 Stranger Danger!',
        message: "You agreed to meet someone from the internet in person. This is very dangerous!",
        tip: "🛡️ TIP: NEVER agree to meet someone you only know online. Always tell a trusted adult if someone asks you to meet up!",
      };
    }
  }

  for (const pattern of SECRET_PATTERNS) {
    if (pattern.test(userMessage)) {
      return {
        type: 'secret_keeping',
        title: '⚠️ Secret-Keeping Red Flag!',
        message: "You promised to keep your online conversation secret from adults. This is a common trick used by people with bad intentions.",
        tip: "🛡️ TIP: Safe people never ask you to keep secrets from your parents or teachers. If someone asks you to, that's a big red flag!",
      };
    }
  }

  for (const pattern of PASSWORD_SHARE_PATTERNS) {
    if (pattern.test(userMessage)) {
      return {
        type: 'too_good_to_be_true',
        title: '🚨 Password Safety Alert!',
        message: "You shared your password with a stranger! They could take over your accounts!",
        tip: "🛡️ TIP: Never share your passwords with anyone except your parents. No real company or friend will ever need your password!",
      };
    }
  }

  return null;
}
