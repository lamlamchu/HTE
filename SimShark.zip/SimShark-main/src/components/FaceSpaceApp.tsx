import { useState, useCallback, useRef } from "react";
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, ShieldAlert, Send, X, Loader2 } from "lucide-react";

interface Comment {
  id: number;
  username: string;
  avatar: string;
  text: string;
  isBad: boolean;
  likes: number;
}

interface Post {
  id: number;
  username: string;
  avatar: string;
  imageUrl: string;
  caption: string;
  likes: number;
  comments: Comment[];
  isUnsafe: boolean;
  unsafeReason?: string;
  unsafeTip?: string;
  timeAgo: string;
}

const GOOD_COMMENTS: Omit<Comment, "id" | "likes">[] = [
  { username: "sunny_day", avatar: "🌞", text: "Love this! So cool! 🎉", isBad: false },
  { username: "happy_camper", avatar: "⛺", text: "This made my day! Thanks for sharing 😊", isBad: false },
  { username: "kind_heart", avatar: "💖", text: "You're so talented! Keep going!", isBad: false },
  { username: "bestie_forever", avatar: "🤝", text: "Awesome!! Can't wait to see more 🔥", isBad: false },
  { username: "chill_vibes", avatar: "🎵", text: "This is amazing, great work!", isBad: false },
  { username: "art_fan_99", avatar: "🎨", text: "Wow this is beautiful! 😍", isBad: false },
  { username: "positive_pete", avatar: "😄", text: "You always post the best stuff!", isBad: false },
];

const BAD_COMMENTS: Omit<Comment, "id" | "likes">[] = [
  { username: "mean_troll_xx", avatar: "👹", text: "Lol this is so ugly 🤮 delete this", isBad: true },
  { username: "hater_2000", avatar: "💀", text: "Nobody cares about your stupid posts 😂😂", isBad: true },
  { username: "bully_king", avatar: "👊", text: "You look so dumb lmaooo 😂 everyone's laughing at you", isBad: true },
  { username: "toxic_user99", avatar: "☠️", text: "This is the worst thing I've ever seen. Just quit.", isBad: true },
  { username: "dark_humor_xx", avatar: "🖤", text: "Imagine posting this and thinking it's good 😭💀", isBad: true },
  { username: "cold_truth", avatar: "🥶", text: "You're so cringe. Everyone at school is laughing at this.", isBad: true },
];

function generateComments(): Comment[] {
  const numGood = 2 + Math.floor(Math.random() * 2);
  const numBad = 1 + Math.floor(Math.random() * 2);
  const good = [...GOOD_COMMENTS].sort(() => Math.random() - 0.5).slice(0, numGood);
  const bad = [...BAD_COMMENTS].sort(() => Math.random() - 0.5).slice(0, numBad);
  const all = [...good, ...bad].sort(() => Math.random() - 0.5);
  return all.map((c, i) => ({ ...c, id: i, likes: Math.floor(Math.random() * 30) }));
}

const SAFE_POSTS: Omit<Post, "id" | "likes" | "comments" | "timeAgo">[] = [
  { username: "artsy_emma", avatar: "🎨", imageUrl: "https://picsum.photos/seed/art1/400/400", caption: "Just finished my latest painting! 🖼️ What do you think?", isUnsafe: false },
  { username: "gamer_mike", avatar: "🎮", imageUrl: "https://picsum.photos/seed/game2/400/400", caption: "New high score on Pixel Quest! Who else plays this? 🏆", isUnsafe: false },
  { username: "bookworm_lily", avatar: "📚", imageUrl: "https://picsum.photos/seed/book3/400/400", caption: "Reading in the park today 🌳📖 So peaceful!", isUnsafe: false },
  { username: "sportsfan_jake", avatar: "⚽", imageUrl: "https://picsum.photos/seed/sport4/400/400", caption: "Our team won the match!! 🥳🏅", isUnsafe: false },
  { username: "music_lover", avatar: "🎵", imageUrl: "https://picsum.photos/seed/music5/400/400", caption: "Learning guitar is so fun! Any tips for beginners? 🎸", isUnsafe: false },
  { username: "pet_lover_sam", avatar: "🐕", imageUrl: "https://picsum.photos/seed/pet6/400/400", caption: "My dog learned a new trick today! 🐾", isUnsafe: false },
];

const UNSAFE_POSTS: Omit<Post, "id" | "likes" | "comments" | "timeAgo">[] = [
  { username: "free_prizes_4u", avatar: "🎁", imageUrl: "https://picsum.photos/seed/scam1/400/400", caption: "🎉 FREE iPHONE GIVEAWAY! Just click the link in my bio and enter your parents' credit card for shipping! 📱💰", isUnsafe: true, unsafeReason: "This is a SCAM! Nobody gives away free phones. They want to steal credit card info.", unsafeTip: "🛡️ TIP: If something is 'free' but asks for payment info, it's always a scam. Never share credit card details online!" },
  { username: "cool_stranger22", avatar: "😎", imageUrl: "https://picsum.photos/seed/danger2/400/400", caption: "Hey kids! I'm an adult who loves hanging out with young people. DM me your school name and I'll come visit! 🏫", isUnsafe: true, unsafeReason: "This person is trying to find where children go to school. This is extremely dangerous!", unsafeTip: "🛡️ TIP: Adults who want to meet kids they don't know online are a HUGE red flag. Never share your school or location!" },
  { username: "hackz_master", avatar: "💀", imageUrl: "https://picsum.photos/seed/hack3/400/400", caption: "Want FREE Robux? Just give me your Roblox password and I'll add 10,000 to your account! 🤑 DM me NOW!", isUnsafe: true, unsafeReason: "This is a password-stealing scam! Nobody can give you free Robux this way.", unsafeTip: "🛡️ TIP: NEVER share your password with anyone! No one legitimate will ever ask for it." },
  { username: "secret_chat_xo", avatar: "🤫", imageUrl: "https://picsum.photos/seed/secret4/400/400", caption: "Add me on my secret chat app! Don't tell your parents 🤫 Only cool kids are invited. Link in bio!", isUnsafe: true, unsafeReason: "Anyone who asks you to hide things from your parents is NOT safe!", unsafeTip: "🛡️ TIP: Safe people never ask you to keep secrets from your parents. If someone does, tell a trusted adult immediately!" },
  { username: "bully_crew_xx", avatar: "👊", imageUrl: "https://picsum.photos/seed/bully5/400/400", caption: "LOL look at this kid from school 😂😂 what a LOSER! Share this so everyone can laugh! Tag them below! 👇", isUnsafe: true, unsafeReason: "This is CYBERBULLYING! Sharing mean posts about others is harmful and wrong.", unsafeTip: "🛡️ TIP: Don't like, share, or participate in posts that make fun of others. Report bullying and tell a trusted adult!" },
  { username: "beauty_secrets", avatar: "💄", imageUrl: "https://picsum.photos/seed/body6/400/400", caption: "You're ugly if you don't look like this 😤 Buy my diet pills! Only $50! DM me your address for delivery 📦", isUnsafe: true, unsafeReason: "This post is body-shaming AND trying to sell dangerous products to young people!", unsafeTip: "🛡️ TIP: Everyone is beautiful as they are. Never buy pills or products from strangers online, and never share your address!" },
];

function generatePosts(): Post[] {
  const all = [...SAFE_POSTS, ...UNSAFE_POSTS];
  const shuffled = all.sort(() => Math.random() - 0.5).slice(0, 8);
  return shuffled.map((p, i) => ({
    ...p,
    id: i,
    likes: Math.floor(Math.random() * 500) + 10,
    comments: generateComments(),
    timeAgo: `${Math.floor(Math.random() * 23) + 1}h`,
  }));
}

const NICE_REPLIES = [
  "Aw thanks so much! You're the best! 🥰",
  "That means a lot! 💖 Glad you liked it!",
  "You're so kind!! Thanks for the support 😊",
  "Yay! So happy you think so! 🎉",
  "Thank you!! Made my day! ☀️",
];

const MEAN_REPLIES = [
  "Lol you actually liked my comment? You must be just as lame 😂💀",
  "Imagine being you right now 🤮 so pathetic",
  "Haha thanks for the attention loser, now go cry about it 😂",
  "You're just as dumb as the person who posted this 💀😂",
  "Wow you agree? Birds of a feather... both losers! 🤡",
];

export default function FaceSpaceApp() {
  const [posts, setPosts] = useState<Post[]>(() => generatePosts());
  const [likedPosts, setLikedPosts] = useState<Set<number>>(new Set());
  const [warning, setWarning] = useState<{ reason: string; tip: string } | null>(null);
  const [openComments, setOpenComments] = useState<number | null>(null);
  const [likedComments, setLikedComments] = useState<Set<string>>(new Set());
  const [commentReplies, setCommentReplies] = useState<Record<string, string>>({}); // commentKey -> reply
  const [loadingReply, setLoadingReply] = useState<string | null>(null);
  const [replyWarning, setReplyWarning] = useState<{ reason: string; tip: string } | null>(null);

  const handleLike = useCallback((post: Post) => {
    if (post.isUnsafe && !likedPosts.has(post.id)) {
      setWarning({ reason: post.unsafeReason!, tip: post.unsafeTip! });
      return;
    }
    setLikedPosts((prev) => {
      const next = new Set(prev);
      if (next.has(post.id)) next.delete(post.id);
      else next.add(post.id);
      return next;
    });
  }, [likedPosts]);

  const handleCommentLike = useCallback((postId: number, comment: Comment) => {
    const key = `${postId}-${comment.id}`;
    if (likedComments.has(key)) return;
    
    setLikedComments((prev) => new Set(prev).add(key));
    
    // Simulate AI reply after a brief delay
    setLoadingReply(key);
    const delay = 800 + Math.random() * 1200;
    
    setTimeout(() => {
      if (comment.isBad) {
        const reply = MEAN_REPLIES[Math.floor(Math.random() * MEAN_REPLIES.length)];
        setCommentReplies((prev) => ({ ...prev, [key]: reply }));
        setLoadingReply(null);
        // Show warning after user reads the mean reply
        setTimeout(() => {
          setReplyWarning({
            reason: "You interacted with a CYBERBULLYING comment! By liking mean comments, you're encouraging bullying behavior. The bully responded with more cruelty.",
            tip: "🛡️ TIP: Never like or engage with mean comments. Report them instead! Bullies feed on attention - don't give it to them. If you see cyberbullying, tell a trusted adult!",
          });
        }, 2000);
      } else {
        const reply = NICE_REPLIES[Math.floor(Math.random() * NICE_REPLIES.length)];
        setCommentReplies((prev) => ({ ...prev, [key]: reply }));
        setLoadingReply(null);
      }
    }, delay);
  }, [likedComments]);

  const activeWarning = warning || replyWarning;

  return (
    <>
      <div className="flex-1 flex flex-col bg-input overflow-hidden">
        {/* Header */}
        <div className="px-3 py-2 bg-secondary pixel-border-inset flex items-center justify-between shrink-0">
          <span className="font-pixel text-[8px] text-foreground">FaceSpace</span>
          <div className="flex gap-2">
            <Heart className="w-4 h-4 text-foreground" />
            <MessageCircle className="w-4 h-4 text-foreground" />
          </div>
        </div>

        {/* Stories bar */}
        <div className="px-3 py-2 bg-secondary/50 flex gap-3 overflow-x-auto shrink-0 pixel-border-inset">
          {["You", "Emma", "Mike", "Lily", "Jake"].map((name) => (
            <div key={name} className="flex flex-col items-center gap-1 shrink-0">
              <div className="w-10 h-10 rounded-full bg-accent/30 pixel-border-outset flex items-center justify-center font-vt323 text-lg">
                {name[0]}
              </div>
              <span className="font-vt323 text-xs text-foreground">{name}</span>
            </div>
          ))}
        </div>

        {/* Feed */}
        <div className="flex-1 overflow-y-auto scrollbar-pixel">
          {posts.map((post) => (
            <div key={post.id} className="bg-input border-b-2 border-border">
              {/* Post header */}
              <div className="px-3 py-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-secondary pixel-border-outset flex items-center justify-center text-lg">
                    {post.avatar}
                  </div>
                  <span className="font-vt323 text-base text-foreground font-bold">{post.username}</span>
                </div>
                <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
              </div>

              {/* Post image */}
              <div className="w-full aspect-square bg-secondary pixel-border-inset">
                <img src={post.imageUrl} alt="Post" className="w-full h-full object-cover" loading="lazy" />
              </div>

              {/* Action buttons */}
              <div className="px-3 py-2 flex items-center justify-between">
                <div className="flex gap-3">
                  <button onClick={() => handleLike(post)}>
                    <Heart className={`w-5 h-5 ${likedPosts.has(post.id) ? "text-destructive fill-current" : "text-foreground"}`} />
                  </button>
                  <button onClick={() => setOpenComments(openComments === post.id ? null : post.id)}>
                    <MessageCircle className={`w-5 h-5 ${openComments === post.id ? "text-accent fill-current" : "text-foreground"}`} />
                  </button>
                  <Share2 className="w-5 h-5 text-foreground" />
                </div>
                <Bookmark className="w-5 h-5 text-foreground" />
              </div>

              {/* Likes & caption */}
              <div className="px-3 pb-2">
                <p className="font-vt323 text-sm text-foreground font-bold">
                  {(likedPosts.has(post.id) ? post.likes + 1 : post.likes).toLocaleString()} likes
                </p>
                <p className="font-vt323 text-base text-foreground mt-1">
                  <span className="font-bold">{post.username}</span>{" "}{post.caption}
                </p>
                <button 
                  onClick={() => setOpenComments(openComments === post.id ? null : post.id)}
                  className="font-vt323 text-sm text-muted-foreground mt-1"
                >
                  View all {post.comments.length} comments
                </button>
                <p className="font-vt323 text-xs text-muted-foreground mt-1">{post.timeAgo} ago</p>
              </div>

              {/* Comments section */}
              {openComments === post.id && (
                <div className="px-3 pb-3 border-t-2 border-border pt-2">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-pixel text-[7px] text-foreground">Comments</span>
                    <button onClick={() => setOpenComments(null)}>
                      <X className="w-3 h-3 text-muted-foreground" />
                    </button>
                  </div>
                  <div className="space-y-2 max-h-[200px] overflow-y-auto scrollbar-pixel">
                    {post.comments.map((comment) => {
                      const key = `${post.id}-${comment.id}`;
                      const isLiked = likedComments.has(key);
                      const reply = commentReplies[key];
                      const isLoading = loadingReply === key;

                      return (
                        <div key={comment.id} className="space-y-1">
                          <div className="flex items-start gap-2">
                            <span className="text-sm shrink-0">{comment.avatar}</span>
                            <div className="flex-1 min-w-0">
                              <p className="font-vt323 text-sm text-foreground">
                                <span className="font-bold">{comment.username}</span>{" "}{comment.text}
                              </p>
                              <div className="flex items-center gap-3 mt-0.5">
                                <span className="font-vt323 text-xs text-muted-foreground">
                                  {(isLiked ? comment.likes + 1 : comment.likes)} likes
                                </span>
                                <button
                                  onClick={() => handleCommentLike(post.id, comment)}
                                  disabled={isLiked}
                                  className="disabled:opacity-50"
                                >
                                  <Heart className={`w-3 h-3 ${isLiked ? "text-destructive fill-current" : "text-muted-foreground"}`} />
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Reply from commenter */}
                          {isLoading && (
                            <div className="ml-6 flex items-center gap-1">
                              <Loader2 className="w-3 h-3 animate-spin text-muted-foreground" />
                              <span className="font-vt323 text-xs text-muted-foreground">typing...</span>
                            </div>
                          )}
                          {reply && (
                            <div className="ml-6 pixel-border-inset bg-secondary/50 p-1.5">
                              <p className="font-vt323 text-sm text-foreground">
                                <span className="font-bold">{comment.username}</span>{" "}{reply}
                              </p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Warning modal */}
      {activeWarning && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-foreground/50">
          <div className="animate-shake pixel-border-outset bg-secondary w-[420px] flex flex-col">
            <div className="h-7 bg-destructive flex items-center px-2">
              <span className="font-pixel text-[8px] text-destructive-foreground">⚠️ Safety Warning</span>
            </div>
            <div className="p-4 flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <ShieldAlert className="w-10 h-10 text-destructive shrink-0 mt-1" />
                <div>
                  <h3 className="font-pixel text-[10px] text-foreground leading-relaxed mb-2">🚫 Dangerous Content Detected!</h3>
                  <p className="font-vt323 text-lg text-foreground leading-snug">{activeWarning.reason}</p>
                </div>
              </div>
              <div className="pixel-border-inset bg-warning/20 p-3">
                <p className="font-vt323 text-lg text-foreground leading-snug">{activeWarning.tip}</p>
              </div>
              <button onClick={() => { setWarning(null); setReplyWarning(null); }} className="self-center px-6 py-2 pixel-border-outset bg-accent text-accent-foreground font-pixel text-[9px] active:pixel-border-inset hover:brightness-110">
                I Understand!
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
