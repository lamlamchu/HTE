import { X, Minus, Square } from "lucide-react";
import { ReactNode, useState, useRef, useEffect } from "react";

interface PixelWindowProps {
  id: string;
  title: string;
  children: ReactNode;
  onClose: () => void;
  onMinimize: () => void;
  initialX?: number;
  initialY?: number;
  width?: number;
  height?: number;
}

export default function PixelWindow({
  title,
  children,
  onClose,
  onMinimize,
  initialX = 100,
  initialY = 50,
  width = 400,
  height = 500,
}: PixelWindowProps) {
  const [pos, setPos] = useState({ x: initialX, y: initialY });
  const [dragging, setDragging] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });

  const handleMouseDown = (e: React.MouseEvent) => {
    setDragging(true);
    dragOffset.current = { x: e.clientX - pos.x, y: e.clientY - pos.y };
  };

  useEffect(() => {
    if (!dragging) return;
    const onMove = (e: MouseEvent) => {
      setPos({ x: e.clientX - dragOffset.current.x, y: e.clientY - dragOffset.current.y });
    };
    const onUp = () => setDragging(false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
  }, [dragging]);

  return (
    <div
      className="absolute animate-window-open pixel-border-outset bg-secondary flex flex-col"
      style={{ left: pos.x, top: pos.y, width, height }}
    >
      {/* Title bar */}
      <div
        className="h-7 bg-window-title flex items-center justify-between px-1 cursor-move select-none shrink-0"
        onMouseDown={handleMouseDown}
      >
        <span className="font-pixel text-[8px] text-window-title-foreground truncate px-1">
          {title}
        </span>
        <div className="flex gap-[2px]">
          <button
            onClick={onMinimize}
            className="w-5 h-5 pixel-border-outset bg-secondary flex items-center justify-center active:pixel-border-inset"
          >
            <Minus className="w-3 h-3 text-foreground" />
          </button>
          <button className="w-5 h-5 pixel-border-outset bg-secondary flex items-center justify-center">
            <Square className="w-3 h-3 text-foreground" />
          </button>
          <button
            onClick={onClose}
            className="w-5 h-5 pixel-border-outset bg-secondary flex items-center justify-center active:pixel-border-inset"
          >
            <X className="w-3 h-3 text-foreground" />
          </button>
        </div>
      </div>

      {/* Menu bar */}
      <div className="h-6 bg-secondary flex items-center gap-4 px-2 text-sm font-vt323 text-foreground border-b border-border shrink-0">
        <span className="hover:bg-accent hover:text-accent-foreground px-1 cursor-pointer">File</span>
        <span className="hover:bg-accent hover:text-accent-foreground px-1 cursor-pointer">Edit</span>
        <span className="hover:bg-accent hover:text-accent-foreground px-1 cursor-pointer">Help</span>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden flex flex-col">
        {children}
      </div>
    </div>
  );
}
