import { useState, useCallback } from "react";
import DesktopIcon from "@/components/DesktopIcon";
import Taskbar from "@/components/Taskbar";
import PixelWindow from "@/components/PixelWindow";
import ChatApp from "@/components/ChatApp";
import FaceSpaceApp from "@/components/FaceSpaceApp";
import PixelMailApp from "@/components/PixelMailApp";
import FactCheckApp from "@/components/FactCheckApp";
import VirusEffect from "@/components/VirusEffect";

type WindowId = "chat" | "facebook" | "mail" | "factcheck";

interface WindowState {
  id: WindowId;
  title: string;
  minimized: boolean;
}

interface MalwareFile {
  fileName: string;
  reason: string;
  tip: string;
}

const Index = () => {
  const [openWindows, setOpenWindows] = useState<WindowState[]>([]);
  const [malwareFile, setMalwareFile] = useState<MalwareFile | null>(null);
  const [virusActive, setVirusActive] = useState(false);

  const openWindow = (id: WindowId) => {
    setOpenWindows((prev) => {
      const existing = prev.find((w) => w.id === id);
      if (existing) {
        return prev.map((w) => (w.id === id ? { ...w, minimized: false } : w));
      }
      const titles: Record<WindowId, string> = {
        chat: "SafeChat - CoolKid99",
        facebook: "FaceSpace Browser",
        mail: "PixelMail",
        factcheck: "FactCheck",
      };
      return [...prev, { id, title: titles[id], minimized: false }];
    });
  };

  const closeWindow = (id: WindowId) => {
    setOpenWindows((prev) => prev.filter((w) => w.id !== id));
  };

  const toggleMinimize = (id: string) => {
    setOpenWindows((prev) =>
      prev.map((w) => (w.id === id ? { ...w, minimized: !w.minimized } : w))
    );
  };

  const handleMalwareDownload = useCallback((fileName: string, reason: string, tip: string) => {
    setMalwareFile({ fileName, reason, tip });
  }, []);

  const handleMalwareClick = useCallback(() => {
    if (malwareFile) {
      setVirusActive(true);
    }
  }, [malwareFile]);

  const handleVirusDismiss = useCallback(() => {
    setVirusActive(false);
    setMalwareFile(null);
  }, []);

  const windowPositions: Record<WindowId, { x: number; y: number; w: number; h: number }> = {
    chat: { x: 60, y: 30, w: 380, h: 500 },
    facebook: { x: 140, y: 20, w: 420, h: 520 },
    mail: { x: 220, y: 40, w: 440, h: 460 },
    factcheck: { x: 300, y: 60, w: 380, h: 420 },
  };

  const renderWindowContent = (id: WindowId) => {
    switch (id) {
      case "chat":
        return <ChatApp />;
      case "facebook":
        return <FaceSpaceApp />;
      case "mail":
        return <PixelMailApp onMalwareDownload={handleMalwareDownload} />;
      case "factcheck":
        return <FactCheckApp />;
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-desktop relative scanlines">
      {/* Virus effect overlay */}
      {virusActive && malwareFile && (
        <VirusEffect
          fileName={malwareFile.fileName}
          reason={malwareFile.reason}
          tip={malwareFile.tip}
          onDismiss={handleVirusDismiss}
        />
      )}

      {/* Desktop area */}
      <div className="flex-1 relative p-4">
        {/* Desktop icons */}
        <div className="flex flex-col gap-2">
          <DesktopIcon
            icon="chat"
            label="SafeChat"
            onClick={() => openWindow("chat")}
            isActive={openWindows.some((w) => w.id === "chat")}
          />
          <DesktopIcon
            icon="facebook"
            label="FaceSpace"
            onClick={() => openWindow("facebook")}
            isActive={openWindows.some((w) => w.id === "facebook")}
          />
          <DesktopIcon
            icon="mail"
            label="PixelMail"
            onClick={() => openWindow("mail")}
            isActive={openWindows.some((w) => w.id === "mail")}
          />
          <DesktopIcon
            icon="factcheck"
            label="FactCheck"
            onClick={() => openWindow("factcheck")}
            isActive={openWindows.some((w) => w.id === "factcheck")}
          />
          {/* Malware file on desktop */}
          {malwareFile && !virusActive && (
            <DesktopIcon
              icon="malware"
              label={malwareFile.fileName}
              onClick={handleMalwareClick}
            />
          )}
        </div>

        {/* Windows */}
        {openWindows
          .filter((w) => !w.minimized)
          .map((win) => {
            const p = windowPositions[win.id];
            return (
              <PixelWindow
                key={win.id}
                id={win.id}
                title={win.title}
                onClose={() => closeWindow(win.id)}
                onMinimize={() => toggleMinimize(win.id)}
                initialX={p.x}
                initialY={p.y}
                width={p.w}
                height={p.h}
              >
                {renderWindowContent(win.id)}
              </PixelWindow>
            );
          })}
      </div>

      {/* Taskbar */}
      <Taskbar openWindows={openWindows} onWindowClick={toggleMinimize} />
    </div>
  );
};

export default Index;
