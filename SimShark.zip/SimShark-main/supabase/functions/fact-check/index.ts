import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { url } = await req.json();

    if (!url || typeof url !== "string") {
      return new Response(
        JSON.stringify({ verdict: "SUSPICIOUS", explanation: "No URL provided.", tips: ["Always verify links before clicking."] }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${Deno.env.get("OPENROUTER_API_KEY")}`,
        "Content-Type": "application/json",
        "HTTP-Referer": Deno.env.get("SITE_URL") || "http://localhost:5173",
        "X-Title": "CyberSafe FactCheck",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-lite",
        messages: [
          {
            role: "system",
            content: `You are a cybersecurity expert for kids. Analyze the given URL/link and determine if it's SAFE, SCAM, or SUSPICIOUS.

Respond ONLY with valid JSON in this format:
{
  "verdict": "SAFE" | "SCAM" | "SUSPICIOUS",
  "explanation": "One clear sentence explaining why, written for a 10-year-old.",
  "tips": ["tip 1", "tip 2", "tip 3"]
}

Rules:
- SCAM: Misspelled brand names (appl3, disc0rd, instagrm), sketchy TLDs (.tk, .xyz, .cc, .biz, .dark, .ru), promises of free money/items, asks for passwords
- SUSPICIOUS: Unknown domains, too-good-to-be-true offers, pressure tactics
- SAFE: Known legitimate domains (.edu, .gov, well-known .com/.org sites)
- Tips should be educational and age-appropriate
- Keep explanation simple and clear`,
          },
          {
            role: "user",
            content: `Analyze this link: ${url}`,
          },
        ],
        temperature: 0.3,
        max_tokens: 300,
      }),
    });

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || "";

    // Parse JSON from response
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return new Response(JSON.stringify(parsed), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(
      JSON.stringify({
        verdict: "SUSPICIOUS",
        explanation: "Could not fully analyze this link. Treat it with caution.",
        tips: ["When in doubt, don't click.", "Ask a trusted adult before visiting unknown sites."],
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("FactCheck error:", error);
    return new Response(
      JSON.stringify({
        verdict: "SUSPICIOUS",
        explanation: "Analysis unavailable. Be cautious with unknown links.",
        tips: ["Never enter personal information on unfamiliar websites."],
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
